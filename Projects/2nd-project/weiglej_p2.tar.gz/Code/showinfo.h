#ifndef SHOWINFO
#define SHOWINFO

void render_bitmap_string (GLfloat, GLfloat, void *, const char *);

void draw_info (GLint);

#endif
