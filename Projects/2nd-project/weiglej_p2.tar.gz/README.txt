Justin Weigle
CG Project 2
Wankel Rotary Engine

FILE OVERVIEW
    hashtable - 
        provides functionality of a hash table for buffer color picking

    drawfunctions - 
        contains the functions for drawing the parts of the engine

    showinfo - 
        contains the info that can be printed to the screen

    weiglej_p2 - 
        contains the main program

MAKEFILE FUNCTIONALITY
    make            -compiles (outputs executable named "rotary")
    make run        -compiles and runs
    make clean      -deletes executable

CLICKABLE OBJECTS
    All objects will display information when clicked, including the white
    space within the housing.
