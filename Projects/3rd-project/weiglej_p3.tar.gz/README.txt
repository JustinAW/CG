Justin Weigle
CG Project 3
Wankel Rotary Engine

CAMERA CONTROLS have been implemented using the keyboard rather than the menu.
Camera controls are as follows:
    A/a -> Rotate camera left / clockwise around the Y axis
    D/d -> Rotate camera right / counter clockwise around the Y axis
    W/w -> Rotate camera clockwise around X axis
    S/s -> Rotate camera counter clockwise around X axis

    E/e -> Zoom in
    Q/q -> Zoom out

MAKEFILE FUNCTIONALITY
    make            -compiles (outputs executable named "rotary")
    make run        -compiles and runs
    make clean      -deletes executable
